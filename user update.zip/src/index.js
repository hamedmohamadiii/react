import ReactDOM from "react-dom";
import "bootstrap/dist/css/bootstrap.min.css"
import App from "./app"


   

ReactDOM.render(<App/>, document.getElementById("root"))
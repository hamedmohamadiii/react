import { Component } from "react";

class Login extends Component {
  
    render() { 
        return (<>
        <h1>login</h1>
        
        
        
        
        </>);
    }
}
 
export default Login;

